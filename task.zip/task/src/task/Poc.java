package task;
import java.io.*;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;



public class Poc {
	public static void main(String[] args) throws Exception	{
		//Class.forName("com.mysql.cj.jdbc.Driver");
		//Class.forName("com.mysql.jdbc.Driver");	
		//		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/student","root","1234");
		//		Statement stmt	=	con.createStatement();
		//		ResultSet	rs	=	stmt.executeQuery("select * from student where studentId=5");
		//		rs.next();
		//		int id	=	rs.getInt("studentId");
		//		String fnm	=	rs.getString("fullName");
		//		String lnm	=	rs.getString("lastName");
		//		int dptId	=	rs.getInt("departmentId");
		//		String	joinDate	=	rs.getString("joiningDate");
		//		String stuDate	=	rs.getString("studentDob");
		//		int mob	=	rs.getInt("mobileNo");
		//		String mail	=	rs.getString("email");
		//		System.out.print(id+" "+fnm+" "+lnm+" "+dptId+" "+joinDate+" "+stuDate+" "+mob+" "+mail+" ");
		//		stmt.close();
		//		con.close();
	/*	Connection con	=	null;
		Statement	st	=	null;
		
		try	{
			con	=	DriverManager.getConnection("jdbc:mysql://localhost:3306/student","root","1234");
			System.out.println("Database Connected");
			st	=	con.createStatement();
			ResultSet	rs	=	st.executeQuery("select * from student where studentId=5");
			rs.next();
			int id	=	rs.getInt("studentId");
			String fnm	=	rs.getString("fullName");
			String lnm	=	rs.getString("lastName");
			int dptId	=	rs.getInt("departmentId");
			String	joinDate	=	rs.getString("joiningDate");
			String stuDate	=	rs.getString("studentDob");
			//BigDecimal	 mob	=	rs.getBigDecimal("mobileNo");
			long mob	=	rs.getLong("mobileNo");
			String mail	=	rs.getString("email");
			System.out.print(id+" "+fnm+" "+lnm+" "+dptId+" "+joinDate+" "+stuDate+" "+mob+" "+mail+" ");

		}
		
	catch	(Exception exe)	{
		exe.printStackTrace();
	}

*/
		File file	=	new	File("C:\\Users\\riya.gurbani\\Downloads\\POC-Data\\input.txt");
		BufferedReader	br	=	new	BufferedReader(new	FileReader(file));
		String str;
		while((str	=	br.readLine())	!=null)
			System.out.println(str);
		

	}
}
