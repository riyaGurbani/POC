package task;
import java.io.*;
import java.sql.*;
public class Delete {
	public static void main(String[] args) throws Exception	{
		Connection con	=	null;
		Statement	st	=	null;
		try	{
			con	=	DriverManager.getConnection("jdbc:mysql://localhost:3306/student","root","1234");
			System.out.println("Database Connected");
			st	=	con.createStatement();
			ResultSet	rs	=	st.executeQuery("delete * from student where studentId=25 and studentId=35");
			rs.next();
			int id	=	rs.getInt("studentId");
			String fnm	=	rs.getString("fullName");
			String lnm	=	rs.getString("lastName");
			int dptId	=	rs.getInt("departmentId");
			String	joinDate	=	rs.getString("joiningDate");
			String stuDate	=	rs.getString("studentDob");
			long mob	=	rs.getLong("mobileNo");
			String mail	=	rs.getString("email");
			//System.out.print(id+" "+fnm+" "+lnm+" "+dptId+" "+joinDate+" "+stuDate+" "+mob+" "+mail+" ");
			rs.close();
			st.close();
			

		}
		
	catch	(Exception exe)	{
		exe.printStackTrace();
	}
		
		
		
		File file	=	new	File("C:\\Users\\riya.gurbani\\Downloads\\POC-Data\\deletestudent.txt");
		BufferedReader	br	=	new	BufferedReader(new	FileReader(file));
		String str;
		while((str	=	br.readLine())	!=null)
			System.out.println(str);
		
		
	}

}
