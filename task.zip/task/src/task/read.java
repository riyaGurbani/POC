package task;
import java.io.File;

import java.io.IOException;
import java.sql.*;
import java.util.Scanner;

class DeptD {
	private int id;
	private String fnm;
	private String lnm;
	private int dptId;
	private String	joinDate;
	private String stuDate;
	private long mob;
	private String mail;


	public void readData()	{
		try(Scanner	input	=	new	Scanner(new	File("C:\\Users\\riya.gurbani\\Downloads\\POC-Data\\input.txt")))	{
			// reading input line by line 
			while(input.hasNextLine()) {

				String line;
				line	=	input.nextLine();
				if(line.length()	<=	0)
					continue;

				// each data item (token based processing)
				try(Scanner	data	=	new	Scanner(line))	{
					while(!data.hasNextInt()) {
						id	+=	data.nextInt();
					}


					//id	=	id.trim();

					if(data.hasNextInt()) {
						fnm	=	data.next()+" ";
					}
					if(data.hasNextInt()) {
						lnm	=	data.next()+" ";
					}
					if(data.hasNextInt()) {
						dptId	=	data.nextInt();
					}
					if(data.hasNextInt()) {
						joinDate=	data.next()+" ";
					}
					if(data.hasNextInt()) {
						stuDate	=	data.next()+" ";
					}
					if(data.hasNextInt()) {
						mob	=	data.nextInt();
					}
					if(data.hasNextInt()) {
						mail	=	data.next()+" ";
					}
				}
			}
		//	saveData();
			//System.out.println(id+"\t"+fnm+"\t"+lnm+"\t"+dptId+"\t"+joinDate+"\t"+stuDate+"\t"+mob+"\t"+mail);
		}
		catch(IOException	e)	{
			System.out.println(e);
		}
	}
}

class read{
	public static void main(String[] args) {
		DeptD	dpt	=	new DeptD();
		try {
			dpt.readData();
			//dpt.displayData();

		}
		catch(Exception e) {
			System.out.print(e);

		}
	}
	private int id;
	private int nm;
	private String fnm;
	private String lnm;
	private int dptId;
	private String	joinDate;
	private String stuDate;
	private long mob;
	private String mail;
	private void saveData() {
		try{
				Connection	con	=	connect();
		
				PreparedStatement	pstmt	=	con.prepareStatement("Insert into student values(?,?,?,?,?,?,?,?)");
						pstmt.setInt(1,id);	
				pstmt.setString(2,fnm);
				pstmt.setString(3,lnm);
				pstmt.setInt(4,dptId);
				pstmt.setString(5,joinDate);
				pstmt.setString(6,stuDate);
				//pstmt.setInt(mob);
				pstmt.setString(8,mail);
				pstmt.executeUpdate();


	}
	catch(SQLException e) {
		System.out.println(e);
	}
		
		public void displayData() {
			try	
			(Connection con	=	connect();
					Statement	stmt		=	con.createStatement())	{
				boolean	 hasResultSet	=	stmt.execute("Select * from student");
				if(hasResultSet) {
					ResultSet	result	=	stmt.getResultSet();
					ResultSetMetaData	metaData	=	result.getMetaData();
					int columnCount	=	metaData.getColumnCount();
					for(int	i=1;i<=columnCount;i++) {
						System.out.print(metaData.getColumnLabel (i)+"\t\t");
						
					}
					System.out.println();
					while(result.next()) {
						System.out.printf("%-20s%10d%10d%n",result.getInt("id"),result.getString("fnm"),result.getString("lnm"),result.getInt("deptId"),result.getString("joinDate"),result.getInt(mob),result.getString(mail));
						 
					}
				}
			}
				
			
			catch(SQLException	e) {
				System.out.println(e);
			}
		}
	private Connection connect() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			return DriverManager.getConnection("jdbc:mysql://localhost:3306/student","root","1234");

		}
		catch(SQLException | ClassNotFoundException e) {
			System.out.println(e);
			return null;

		}
	}
}
