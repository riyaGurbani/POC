package task;

import java.sql.Connection;
import java.sql.DriverManager;

import java.sql.SQLException;
import java.sql.ResultSet;
import java.sql.Statement;

public class Crud {
	public static void main(String[] args) throws Exception	{
		Connection con	=	null;
		Statement	st	=	null;

		try {
			// Connection 

			con	=	DriverManager.getConnection("jdbc:mysql://localhost:3306/student","root","1234");
			System.out.println("Database Connected");
			// Inserting rows
			String sql ="INSERT INTO `department` VALUES (11,'CS'),(22,'EEE'),(33,'IT'),(44,'ECE'),(55,'Arch'),(66,'Mech')";
			st	=	con.createStatement();
			int rows	=	st.executeUpdate(sql);
			if(rows	>	0) {
				System.out.println("Record Inserted Successfully!");

			}

			// Updating rows
			String update	=	"Update department set  departmentName='ABC' where departmentId=4";
			st	=	con.createStatement();
			int row	=	st.executeUpdate(update);
			if(row	>	0) {
				System.out.println("Record Updated Successfully!");

			}

		}

		catch	(Exception exe)	{
			exe.printStackTrace();
		}

	}
}
